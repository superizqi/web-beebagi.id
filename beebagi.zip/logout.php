<?php
include 'conn.php';
unset($_SESSION['username']);
// echo "Selamat";
header("Location: index.php");

 ?>
