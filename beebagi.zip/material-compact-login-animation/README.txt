A Pen created at CodePen.io. You can find this one at https://codepen.io/thio_fauzi/pen/GzjXeQ.

 Material Compact Login Animation ,  @MaterialUp Tweet https://twitter.com/MaterialUp/status/622009685521113088 , Compact Login - Animation by @noxiousone made with Sketch & After Effects #materialdesign :)