<?php
session_start();
echo "Selamat Datang";
echo "<br>";
echo $_SESSION['username'];

?>
